package JAKJ . RedstoneInMotion ;

public enum PacketTypes
{
	Render ,
	MultipartPropagation ;
}
