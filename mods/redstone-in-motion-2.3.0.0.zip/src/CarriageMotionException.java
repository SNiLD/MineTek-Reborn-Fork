package JAKJ . RedstoneInMotion ;

public class CarriageMotionException extends Exception
{
	public CarriageMotionException ( String Message )
	{
		super ( Message ) ;
	}
}
